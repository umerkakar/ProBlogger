# Responsive Menu jQuery
Responsive menu made with jQuery by Muhammad Adam Firdaus.

### DEMO
http://www.muhammadadamfirdaus.com/on/menu/

![Preview]
(http://g.recordit.co/VVxa5QSyHV.gif)

change to mobile views for adjust menu on mobile.
